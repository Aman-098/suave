#!/usr/bin/env bash
set -euo pipefail
cd /var/www/suave
php artisan view:clear
php artisan seo:import storage/app/seo
echo
php artisan seo:audit || true

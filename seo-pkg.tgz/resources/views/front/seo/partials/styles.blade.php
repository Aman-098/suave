{{-- Scoped to .seo-* only. Uses the site's existing palette:
     gold #BE9B5A / #C9A765, dark #222, body text #86898E, headings #fff,
     Plus Jakarta Sans. Nothing here overrides an existing theme class. --}}
<style>
    .seo-page-standfirst{max-width:820px;margin:14px auto 0;color:#86898E;font-size:16px;line-height:1.7}
    .seo-consult-sub{color:#86898E;margin:-6px 0 18px;font-size:15px}
    .seo-consult-submit{margin-top:18px}
    .seo-consult-call{margin-top:14px;color:#86898E;font-size:14px}
    .seo-consult-call a{color:#C9A765;font-weight:600}

    .seo-body{padding:60px 0 20px}
    .seo-body p,.seo-body li{color:#86898E;font-size:16px;line-height:1.8}
    .seo-body h2{color:#fff;font-size:26px;font-weight:700;margin:0 0 16px;line-height:1.35}
    .seo-body h3{color:#fff;font-size:19px;font-weight:600;margin:24px 0 10px}
    .seo-body a{color:#C9A765}
    .seo-body a:hover{color:#BE9B5A}

    .seo-answer{border-left:3px solid #BE9B5A;background:rgba(190,155,90,.07);
        padding:20px 24px;border-radius:6px;margin:0 0 40px}
    .seo-answer p{color:#e8e8e8;font-size:17px;line-height:1.75;margin:0}

    .seo-section{margin:0 0 40px}

    .seo-table-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch}
    .seo-table{width:100%;border-collapse:collapse;min-width:520px}
    .seo-table th,.seo-table td{padding:12px 14px;text-align:left;
        border-bottom:1px solid rgba(255,255,255,.09);font-size:15px;color:#86898E}
    .seo-table th{color:#fff;font-weight:600;background:rgba(190,155,90,.12);white-space:nowrap}
    .seo-table tbody tr:hover td{background:rgba(255,255,255,.03)}

    .seo-faq-item{border-bottom:1px solid rgba(255,255,255,.09);padding:14px 0}
    .seo-faq-item summary{color:#fff;font-weight:600;font-size:17px;cursor:pointer;list-style:none;
        display:flex;justify-content:space-between;gap:16px}
    .seo-faq-item summary::-webkit-details-marker{display:none}
    .seo-faq-item summary::after{content:"+";color:#BE9B5A;font-size:22px;line-height:1}
    .seo-faq-item[open] summary::after{content:"\2212"}
    .seo-faq-answer{padding-top:10px}

    .seo-links{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:24px;
        margin:48px 0;padding:28px 0;border-top:1px solid rgba(255,255,255,.09);
        border-bottom:1px solid rgba(255,255,255,.09)}
    .seo-linkblock-title{color:#fff;font-size:15px;font-weight:700;text-transform:uppercase;
        letter-spacing:.08em;margin:0 0 12px}
    .seo-linkblock-list{list-style:none;padding:0;margin:0}
    .seo-linkblock-list li{margin:0 0 8px}
    .seo-linkblock-list a{color:#C9A765;font-size:15px}

    .seo-byline{margin:32px 0;padding:16px 20px;background:rgba(255,255,255,.03);border-radius:6px}
    .seo-byline p{margin:0;font-size:14px;color:#86898E}
    .seo-byline strong{color:#fff}

    .seo-sources{margin:32px 0}
    .seo-sources h2{font-size:19px}
    .seo-sources ol{padding-left:20px}
    .seo-sources li{margin-bottom:8px;font-size:14px}

    .seo-cta{margin:48px 0 20px;padding:34px 28px;background:#1a1a1a;border-radius:10px;text-align:center}
    .seo-cta h2{margin-bottom:12px}
    .seo-cta p{max-width:620px;margin:0 auto 22px}
    .seo-cta .more-link{display:inline-block;margin:6px}

    @media (max-width:767px){
        .seo-body{padding:40px 0 10px}
        .seo-body h2{font-size:22px}
        .seo-answer{padding:16px 18px}
        .seo-answer p{font-size:16px}
    }
</style>

{{-- Above-the-fold enquiry form. Same markup family as the fleet detail page
     (.suave-consult-*) so the fold, spacing and colours are unchanged. --}}
<section>
    <div class="suave-consult-wrap">
        <div class="suave-consult-card">
            <h2 class="suave-consult-title">{{ $formTitle ?? 'Get a Free Quote' }}</h2>
            <p class="seo-consult-sub">{{ $formSub ?? 'Tell us where you are going and when. We will come back with a tailored price.' }}</p>

            <form id="seo_enquiry_form" method="POST" action="{{ route('footer.save') }}">
                @csrf
                <input type="hidden" name="source_page" value="{{ $page->url_path }}">

                <div class="suave-consult-row">
                    <div class="suave-consult-field">
                        <label for="seo_name">Name</label>
                        <input type="text" name="name" id="seo_name" autocomplete="name">
                        <span class="text-danger" id="seoNameError"></span>
                    </div>
                    <div class="suave-consult-field">
                        <label for="seo_phone">Phone</label>
                        <input type="tel" name="phone" id="seo_phone" autocomplete="tel">
                        <span class="text-danger" id="seoPhoneError"></span>
                    </div>
                </div>

                <div class="suave-consult-row">
                    <div class="suave-consult-field">
                        <label for="seo_email">Email</label>
                        <input type="email" name="email" id="seo_email" autocomplete="email">
                        <span class="text-danger" id="seoEmailError"></span>
                    </div>
                    <div class="suave-consult-field">
                        <label for="seo_message">Journey details</label>
                        <input type="text" name="message" id="seo_message"
                               placeholder="{{ $formPlaceholder ?? 'Date, pick-up and vehicle' }}">
                        <span class="text-danger" id="seoMessageError"></span>
                    </div>
                </div>

                <button type="submit" class="more-link seo-consult-submit">Get My Quote</button>

                <p class="seo-consult-call">
                    Prefer to talk? Call <a href="tel:08081680808">0808 168 0808</a>
                </p>
            </form>
        </div>
    </div>
</section>
